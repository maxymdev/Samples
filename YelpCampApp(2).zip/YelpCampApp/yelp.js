var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var path    = require("path");

app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine", "ejs");



var campgrounds = [
        {name: "Hills", image:"https://farm6.staticflickr.com/5181/5641024448_04fefbb64d.jpg"},
        {name: "Montana", image:"https://farm5.staticflickr.com/4153/4835814837_feef6f969b.jpg"},
        {name: "Camp120", image:"https://farm4.staticflickr.com/3270/2617191414_c5d8a25a94.jpg"},
        {name: "Anegro", image:"https://farm4.staticflickr.com/3872/14435096036_39db8f04bc.jpg"},
        {name: "Swetzer", image:"https://farm2.staticflickr.com/1281/4684194306_18ebcdb01c.jpg"},
        {name: "Daily Camp", image:"https://farm8.staticflickr.com/7205/7121863467_eb0aa64193.jpg"},
        {name: "Forest", image:"https://farm8.staticflickr.com/7042/7121867321_65b5f46ef1.jpg"},
        {name: "Land", image:"https://farm2.staticflickr.com/1363/1342367857_2fd12531e7.jpg"}
        
        ];

app.get("/", function(req, res){
    // res.send("Camping here");
    res.render("landing");
});

app.get("/campgrounds", function(req, res){
    res.render("grounds", {campgrounds:campgrounds});
});




app.get("/campgrounds/new", function(req, res){
   res.render("new"); 
});

app.post("/campgrounds", function(req, res){
    var name = req.body.name;
    var image = req.body.image;
    campgrounds.push({name:name, image:image});
    res.redirect("/campgrounds");
});


app.use(express.static(__dirname + '/Radchenko/ImgGallery/'));
app.use(express.static(__dirname + '/Radchenko/PatatapClone/'));
app.use(express.static(__dirname + '/Radchenko/RGBGuessGame/'));
app.use(express.static(__dirname + '/Radchenko/TodoList/'));
app.use(express.static(__dirname + '/Radchenko/'));

app.get("/imggallery", function(req, res){
    res.sendFile(path.join(__dirname+'/Radchenko/ImgGallery/image_gallery.html'));
    // res.render("Radchenko/ImgGallery/image_gallery");
});

app.get("/patatapclone", function(req, res){
    res.sendFile(path.join(__dirname+'/Radchenko/PatatapClone/keytap.html'));
    // res.render("Radchenko/PatatapClone/keytap");
});

app.get("/rgbguessgame", function(req, res){
    res.sendFile(path.join(__dirname+'/Radchenko/RGBGuessGame/RGB.html'));
    // res.render("Radchenko/RGBGuessGame/RGB");
});

app.get("/todo", function(req, res){
    res.sendFile(path.join(__dirname+'/Radchenko/TodoList/index.html'));
    // res.render("Radchenko/TodoList/index");
});

app.get("/download", function(req, res){
    res.download(path.join(__dirname+'/Radchenko/', "YelpCampApp.zip"));
    // res.render("Radchenko/TodoList/index");
});


app.listen(process.env.PORT, process.env.IP, function() {
    console.log("The YelpCamp");
});

